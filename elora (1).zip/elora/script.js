/* =============================================================
   ELORA — Natural skincare
   script.js
   -------------------------------------------------------------
   1. Product catalogue (edit here to change products/prices)
   2. Helpers
   3. Product rendering & filters
   4. Cart (add, remove, quantities, totals, saved in browser)
   5. Toast notification
   6. Header, mobile menu & active links
   7. Scroll reveal animations
   8. Contact form & newsletter validation
   9. Modals (privacy, terms, order)
   10. Init
   ============================================================= */

/* ---------- 1. Product catalogue ---------- */
const CATEGORIES = {
  facial: 'Facial care',
  body: 'Body care',
  'lip-hair': 'Lip & hair care'
};

const PRODUCTS = [
  // FACIAL CARE
  { id: 'pure-glow-serum', name: 'Pure Glow Serum', category: 'facial', price: 38.00, size: '30 ml', badge: 'Bestseller', featured: true,
    description: 'A lightweight serum with niacinamide and Mediterranean prickly pear to brighten and even out the skin.' },
  { id: 'hydrating-face-cream', name: 'Hydrating Face Cream', category: 'facial', price: 42.00, size: '50 ml', featured: true,
    description: 'Velvety daily cream with hyaluronic acid and aloe vera for 24-hour hydration and a soft, plump feel.' },
  { id: 'botanical-cleanser', name: 'Botanical Cleanser', category: 'facial', price: 24.00, size: '150 ml',
    description: 'A gentle gel-to-milk cleanser with chamomile and green tea that removes impurities without stripping.' },
  { id: 'vitamin-c-face-oil', name: 'Vitamin C Face Oil', category: 'facial', price: 34.00, size: '30 ml', badge: 'New',
    description: 'Radiance-boosting dry oil with sea buckthorn and orange peel, rich in natural vitamin C.' },

  // BODY CARE
  { id: 'coconut-body-scrub', name: 'Coconut Body Scrub', category: 'body', price: 26.00, size: '250 g',
    description: 'Exfoliating scrub with coconut oil, brown sugar and fine sea salt for silky, renewed skin.' },
  { id: 'aloe-vera-body-lotion', name: 'Aloe Vera Body Lotion', category: 'body', price: 22.00, size: '250 ml', featured: true,
    description: 'Fresh, fast-absorbing lotion with organic aloe vera and cucumber to soothe and hydrate.' },
  { id: 'natural-body-butter', name: 'Natural Body Butter', category: 'body', price: 28.00, size: '200 ml',
    description: 'Rich whipped butter with shea, cocoa and olive oil for deep nourishment of very dry skin.' },
  { id: 'ocean-breeze-body-mist', name: 'Ocean Breeze Body Mist', category: 'body', price: 19.00, size: '100 ml', badge: 'New', featured: true,
    description: 'A light, refreshing mist with notes of sea salt, bergamot and fig leaf. Summer in a bottle.' },

  // LIP CARE & HAIR CARE
  { id: 'nourishing-lip-balm', name: 'Nourishing Lip Balm', category: 'lip-hair', price: 12.00, size: '4.5 g',
    description: 'Vegan balm with candelilla wax, shea and rosehip oil to protect and soften the lips.' },
  { id: 'natural-hair-mask', name: 'Natural Hair Mask', category: 'lip-hair', price: 29.00, size: '200 ml', badge: 'Bestseller',
    description: 'Intensive repair mask with argan oil and lavender for strong, shiny and manageable hair.' },
  { id: 'botanical-shampoo', name: 'Botanical Shampoo', category: 'lip-hair', price: 21.00, size: '300 ml',
    description: 'Sulphate-free shampoo with rosemary and nettle that cleanses gently and adds natural volume.' },
  { id: 'softening-hair-conditioner', name: 'Softening Hair Conditioner', category: 'lip-hair', price: 23.00, size: '300 ml',
    description: 'Silicone-free conditioner with olive and oat proteins that detangles and softens every strand.' }
];

// Shipping rules (demo)
const FREE_SHIPPING_FROM = 50;
const SHIPPING_COST = 4.95;
const STORAGE_KEY = 'elora-cart';

/* ---------- 2. Helpers ---------- */
const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

// Format a number as euros in Spanish format: 1234.5 -> "1.234,50 €"
const formatPrice = (value) =>
  new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(value);

const imagePath = (product) => `assets/img/products/${product.id}.jpg`;
const findProduct = (id) => PRODUCTS.find((p) => p.id === id);

/* ---------- 3. Product rendering & filters ---------- */
function productCard(product) {
  return `
    <article class="card" data-category="${product.category}">
      <div class="card__media">
        <img src="${imagePath(product)}" alt="${product.name} by ELORA, ${product.size}" loading="lazy" width="720" height="900">
        ${product.badge ? `<span class="card__badge">${product.badge}</span>` : ''}
        <button class="card__quick" data-add="${product.id}" aria-label="Quick add ${product.name} to cart">Quick add +</button>
      </div>
      <div class="card__body">
        <div class="card__top">
          <h3 class="card__title">${product.name}</h3>
          <span class="card__price">${formatPrice(product.price)}</span>
        </div>
        <span class="card__cat">${CATEGORIES[product.category]} · ${product.size}</span>
        <p class="card__desc">${product.description}</p>
        <button class="add-btn" data-add="${product.id}">Add to cart</button>
      </div>
    </article>`;
}

function renderProducts() {
  $('#productGrid').innerHTML = PRODUCTS.map(productCard).join('');
  $('#featuredGrid').innerHTML = PRODUCTS.filter((p) => p.featured).map(productCard).join('');
  updateShopCount(PRODUCTS.length);
}

function updateShopCount(n) {
  $('#shopCount').textContent = `Showing ${n} ${n === 1 ? 'product' : 'products'}`;
}

function setupFilters() {
  $$('.filter').forEach((button) => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;

      // Update active button
      $$('.filter').forEach((b) => {
        const active = b === button;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-selected', active);
      });

      // Show / hide product cards (only inside the shop grid)
      let visible = 0;
      $$('#productGrid .card').forEach((card) => {
        const show = filter === 'all' || card.dataset.category === filter;
        card.classList.toggle('is-hidden', !show);
        if (show) {
          visible++;
          // restart the entrance animation
          card.style.animation = 'none';
          void card.offsetWidth;
          card.style.animation = '';
        }
      });
      updateShopCount(visible);
    });
  });
}

/* ---------- 4. Cart ---------- */
// The cart is an array of { id, qty }
let cart = loadCart();

function loadCart() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    // keep only valid products
    return Array.isArray(saved) ? saved.filter((item) => findProduct(item.id) && item.qty > 0) : [];
  } catch (e) {
    return [];
  }
}

function saveCart() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(cart)); } catch (e) { /* storage not available: cart still works in memory */ }
}

function addToCart(id, qty = 1) {
  const item = cart.find((i) => i.id === id);
  if (item) item.qty += qty;
  else cart.push({ id, qty });
  saveCart();
  renderCart();
  bumpCounter();
  showToast(findProduct(id));
}

function changeQty(id, delta) {
  const item = cart.find((i) => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter((i) => i.id !== id);
  saveCart();
  renderCart();
}

function removeFromCart(id) {
  cart = cart.filter((i) => i.id !== id);
  saveCart();
  renderCart();
}

function clearCart() {
  cart = [];
  saveCart();
  renderCart();
}

function cartTotals() {
  const count = cart.reduce((sum, i) => sum + i.qty, 0);
  const subtotal = cart.reduce((sum, i) => sum + findProduct(i.id).price * i.qty, 0);
  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_FROM ? 0 : SHIPPING_COST;
  return { count, subtotal, shipping, total: subtotal + shipping };
}

function renderCart() {
  const { count, subtotal, shipping, total } = cartTotals();

  // Header counter
  $('#cartCount').textContent = count;
  $('#cartHeadCount').textContent = count ? `(${count})` : '';

  // Empty state
  $('#cart').classList.toggle('is-empty', count === 0);

  // Items
  $('#cartItems').innerHTML = cart.map((item) => {
    const p = findProduct(item.id);
    return `
      <li class="cart-item">
        <img src="${imagePath(p)}" alt="${p.name}">
        <div>
          <div class="cart-item__name">${p.name}</div>
          <div class="cart-item__unit">${formatPrice(p.price)} · ${p.size}</div>
          <div class="qty" aria-label="Quantity">
            <button data-qty="-1" data-id="${p.id}" aria-label="Decrease quantity of ${p.name}">−</button>
            <span>${item.qty}</span>
            <button data-qty="1" data-id="${p.id}" aria-label="Increase quantity of ${p.name}">+</button>
          </div>
        </div>
        <div class="cart-item__right">
          <span class="cart-item__total">${formatPrice(p.price * item.qty)}</span>
          <button class="cart-item__remove" data-remove="${p.id}">Remove</button>
        </div>
      </li>`;
  }).join('');

  // Free-shipping progress
  const shipBox = $('#cartShipping');
  if (count === 0) {
    shipBox.innerHTML = '';
  } else {
    const missing = FREE_SHIPPING_FROM - subtotal;
    const pct = Math.min(100, (subtotal / FREE_SHIPPING_FROM) * 100);
    shipBox.innerHTML = `${missing > 0
      ? `You are <strong>${formatPrice(missing)}</strong> away from free shipping.`
      : 'Great news — your order ships <strong>for free</strong>.'}
      <div class="cart__bar"><span style="width:${pct}%"></span></div>`;
  }

  // Totals
  $('#cartSubtotal').textContent = formatPrice(subtotal);
  $('#cartShip').textContent = shipping === 0 ? 'Free' : formatPrice(shipping);
  $('#cartTotal').textContent = formatPrice(total);
}

function bumpCounter() {
  const counter = $('#cartCount');
  counter.classList.remove('bump');
  void counter.offsetWidth; // restart animation
  counter.classList.add('bump');
}

function openCart() {
  hideToast();
  $('#cart').classList.add('is-open');
  $('#cart').setAttribute('aria-hidden', 'false');
  $('#overlay').classList.add('is-visible');
  document.body.classList.add('no-scroll');
}

function closeCart() {
  $('#cart').classList.remove('is-open');
  $('#cart').setAttribute('aria-hidden', 'true');
  $('#overlay').classList.remove('is-visible');
  document.body.classList.remove('no-scroll');
}

function setupCart() {
  // "Add to cart" buttons (event delegation: works for every product card)
  document.addEventListener('click', (e) => {
    const addBtn = e.target.closest('[data-add]');
    if (addBtn) {
      addToCart(addBtn.dataset.add);
      if (addBtn.classList.contains('add-btn')) {
        addBtn.textContent = 'Added ✓';
        addBtn.classList.add('is-added');
        setTimeout(() => {
          addBtn.textContent = 'Add to cart';
          addBtn.classList.remove('is-added');
        }, 1400);
      }
    }
  });

  // Quantity and remove buttons inside the cart
  $('#cartItems').addEventListener('click', (e) => {
    const qtyBtn = e.target.closest('[data-qty]');
    if (qtyBtn) changeQty(qtyBtn.dataset.id, Number(qtyBtn.dataset.qty));
    const removeBtn = e.target.closest('[data-remove]');
    if (removeBtn) removeFromCart(removeBtn.dataset.remove);
  });

  $('#cartOpen').addEventListener('click', openCart);
  $('#cartClose').addEventListener('click', closeCart);
  $('#overlay').addEventListener('click', closeCart);
  $('#cartShopLink').addEventListener('click', closeCart);
  $('#clearCart').addEventListener('click', clearCart);

  // Demo checkout
  $('#checkoutBtn').addEventListener('click', () => {
    const { count, total } = cartTotals();
    $('#orderText').textContent =
      `You ordered ${count} ${count === 1 ? 'item' : 'items'} for a total of ${formatPrice(total)}. ` +
      'This is a demo store, so no payment has been taken.';
    clearCart();
    closeCart();
    openModal('orderModal');
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeCart(); closeModals(); }
  });
}

/* ---------- 5. Toast notification ---------- */
let toastTimer;
function showToast(product) {
  const toast = $('#toast');
  toast.innerHTML = `
    <img src="${imagePath(product)}" alt="">
    <span><strong>${product.name}</strong> added to your cart</span>
    <button type="button" id="toastView">View cart</button>`;
  toast.classList.add('is-visible');
  $('#toastView').addEventListener('click', () => { hideToast(); openCart(); });
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, 3200);
}
function hideToast() { $('#toast').classList.remove('is-visible'); }

/* ---------- 6. Header, mobile menu & active links ---------- */
function setupHeader() {
  const header = $('#header');
  const toggle = $('#menuToggle');
  const nav = $('#nav');

  // Solid header background after scrolling
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 40);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // Mobile menu
  const closeMenu = () => {
    nav.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Open menu');
  };
  toggle.addEventListener('click', () => {
    const open = !nav.classList.contains('is-open');
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open);
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    if (open) header.classList.add('is-scrolled');
  });
  $$('.nav__link').forEach((link) => link.addEventListener('click', closeMenu));

  // Highlight the menu link of the section on screen
  const links = $$('.nav__link');
  const sections = links.map((l) => $(l.getAttribute('href'))).filter(Boolean);
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          links.forEach((l) => l.classList.toggle('is-active', l.getAttribute('href') === `#${entry.target.id}`));
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach((s) => observer.observe(s));
  }
}

/* ---------- 7. Scroll reveal animations ---------- */
function setupReveal() {
  const items = $$('.reveal');
  if (!('IntersectionObserver' in window)) {
    items.forEach((el) => el.classList.add('is-visible'));
    return;
  }
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  items.forEach((el) => observer.observe(el));
}

/* ---------- 8. Contact form & newsletter validation ---------- */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function setupContactForm() {
  const form = $('#contactForm');
  const success = $('#formSuccess');

  const rules = {
    name: (v) => v.trim().length >= 2 || 'Please enter your name (at least 2 characters).',
    email: (v) => EMAIL_RE.test(v.trim()) || 'Please enter a valid email address.',
    message: (v) => v.trim().length >= 10 || 'Your message should have at least 10 characters.'
  };

  const validateField = (field) => {
    const result = rules[field.name](field.value);
    const error = $(`[data-error-for="${field.name}"]`, form);
    const ok = result === true;
    field.classList.toggle('is-invalid', !ok);
    field.setAttribute('aria-invalid', !ok);
    error.textContent = ok ? '' : result;
    return ok;
  };

  // Validate again while the user corrects a field
  Object.keys(rules).forEach((name) => {
    const field = form.elements[name];
    field.addEventListener('input', () => {
      if (field.classList.contains('is-invalid')) validateField(field);
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fields = Object.keys(rules).map((name) => form.elements[name]);
    const results = fields.map(validateField);
    if (results.every(Boolean)) {
      success.hidden = false;
      form.reset();
      setTimeout(() => { success.hidden = true; }, 6000);
    } else {
      success.hidden = true;
      fields[results.indexOf(false)].focus();
    }
  });
}

function setupNewsletter() {
  const form = $('#newsletterForm');
  const input = $('#newsletterEmail');
  const msg = $('#newsletterMsg');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const ok = EMAIL_RE.test(input.value.trim());
    msg.className = `newsletter__msg ${ok ? 'is-ok' : 'is-error'}`;
    msg.textContent = ok
      ? 'Welcome to ELORA! Check your inbox for your 10% code.'
      : 'Please enter a valid email address.';
    if (ok) form.reset();
  });
}

/* ---------- 9. Modals ---------- */
function openModal(id) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('no-scroll');
  const close = $('.modal__close', modal);
  if (close) close.focus();
}

function closeModals() {
  $$('.modal.is-open').forEach((m) => {
    m.classList.remove('is-open');
    m.setAttribute('aria-hidden', 'true');
  });
  if (!$('#cart').classList.contains('is-open')) document.body.classList.remove('no-scroll');
}

function setupModals() {
  $$('[data-modal]').forEach((btn) => btn.addEventListener('click', () => openModal(btn.dataset.modal)));
  $$('.modal').forEach((modal) => {
    modal.addEventListener('click', (e) => {
      // close when clicking the dark background, the × or the OK button
      if (e.target === modal || e.target.closest('.modal__close') || e.target.closest('.modal__ok')) closeModals();
    });
  });
}

/* ---------- 10. Init ---------- */
document.addEventListener('DOMContentLoaded', () => {
  renderProducts();
  setupFilters();
  setupCart();
  renderCart();
  setupHeader();
  setupReveal();
  setupContactForm();
  setupNewsletter();
  setupModals();
  $('#year').textContent = new Date().getFullYear();
});
