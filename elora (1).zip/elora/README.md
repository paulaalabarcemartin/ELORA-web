# ELORA · Pure beauty, naturally.

Web de demostración de ELORA, marca ficticia de cosmética natural, vegana y sostenible.
Hecha solo con HTML, CSS y JavaScript: no necesita servidor, base de datos ni ningún servicio de pago.

## Estructura del proyecto

```
elora/
├── index.html          ← página principal (todas las secciones)
├── style.css           ← diseño, colores, animaciones y versión móvil
├── script.js           ← productos, filtros, carrito, formularios
├── README.md           ← este archivo
└── assets/
    ├── favicon.svg     ← icono de la pestaña
    ├── fonts/          ← tipografías (Instrument Serif y Manrope, licencia libre OFL)
    └── img/
        ├── hero.jpg    ← imagen principal
        ├── band.jpg    ← franja con toda la colección
        ├── about.jpg   ← imagen de "About us"
        └── products/   ← 12 fotos de producto (una por producto)
```

Todas las fotos de producto son renders 3D creados para ELORA: puedes usarlas libremente.

Importante: sube los archivos **tal cual**, respetando la carpeta `assets` y sus subcarpetas (`fonts`, `img`, `img/products`). Todas las rutas son relativas, así que funciona igual en tu ordenador y en GitHub Pages.

## Ver la web en tu ordenador

Haz doble clic en `index.html` y se abrirá en el navegador.

## Publicarla gratis con GitHub Pages

1. **Crea una cuenta** en https://github.com (gratis) e inicia sesión.
2. **Crea un repositorio**: botón verde **New** (o el **+** de arriba a la derecha → *New repository*).
   - Repository name: `elora` (o el nombre que quieras, sin espacios).
   - Marca **Public**.
   - Pulsa **Create repository**.
3. **Sube los archivos**: en el repositorio vacío, pulsa el enlace **uploading an existing file**.
   - Descomprime el .zip en tu ordenador.
   - Abre la carpeta `elora` y **arrastra su contenido** (index.html, style.css, script.js, README.md y la carpeta assets) a la ventana de GitHub. No arrastres la carpeta `elora` entera: `index.html` tiene que quedar en la raíz del repositorio.
   - Espera a que terminen de cargarse todos los archivos y pulsa **Commit changes**.
4. **Activa GitHub Pages**: en el repositorio, ve a **Settings** → en el menú de la izquierda, **Pages**.
   - En *Build and deployment* → *Source*, elige **Deploy from a branch**.
   - En *Branch*, elige **main** y la carpeta **/(root)**. Pulsa **Save**.
5. **Espera 1–3 minutos** y recarga la página de *Settings → Pages*. Arriba aparecerá:
   *Your site is live at* `https://TU-USUARIO.github.io/elora/`
   Ese es el enlace público de tu web.

### Si algo no se ve bien
- **Sale un error 404**: espera un par de minutos más y comprueba que `index.html` está en la raíz del repositorio (no dentro de otra carpeta).
- **No se ven las imágenes**: comprueba que existe la carpeta `assets/img/products` en el repositorio con sus 12 archivos. GitHub distingue mayúsculas y minúsculas: no cambies los nombres.
- **Subir carpetas**: si al arrastrar no se suben las carpetas, usa Chrome o Edge, o sube la carpeta `assets` arrastrándola entera (no su contenido suelto).
- **Cambios que no aparecen**: tras subir cambios, espera 1–2 minutos y recarga con Ctrl + F5 (Cmd + Shift + R en Mac).

## Cómo hacer cambios

- **Precios, nombres y descripciones**: en `script.js`, sección `1. Product catalogue`.
- **Textos de las secciones**: en `index.html` (cada sección está marcada con un comentario).
- **Colores**: en `style.css`, al principio, dentro de `:root`.
- **Envío gratis**: en `script.js`, `FREE_SHIPPING_FROM` (50 €) y `SHIPPING_COST` (4,95 €).
- **Cambiar la foto de un producto**: sustituye el archivo en `assets/img/products/` por otro .jpg con el mismo nombre (por ejemplo `pure-glow-serum.jpg`), mejor en formato vertical 4:5 (720 × 900 px).
- Para editar archivos directamente en GitHub: abre el archivo → icono del lápiz → cambia → **Commit changes**.

## Funcionalidades

- Navegación entre secciones con menú fijo y menú móvil.
- Catálogo de 12 productos con filtros por categoría.
- Carrito lateral: añadir, eliminar, cambiar cantidades, subtotal, envío y total automáticos.
- Contador del carrito y aviso al añadir un producto.
- El carrito se guarda en el navegador (sigue ahí si recargas la página).
- Pago de demostración (no se cobra nada).
- Formulario de contacto y newsletter con validación.
- Política de privacidad y términos en ventanas emergentes.
- Diseño adaptado a móvil, tablet y ordenador.

> Nota: es una tienda de demostración. Los formularios validan los datos pero no envían correos.
